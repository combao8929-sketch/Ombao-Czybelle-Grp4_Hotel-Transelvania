/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.hoteltranselvania;

/**
 *
 * @author april
 */
public class HotelTranselvania {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
