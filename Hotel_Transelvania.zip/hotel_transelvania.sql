-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 10, 2025 at 03:02 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hotel_transelvania`
--

-- --------------------------------------------------------

--
-- Table structure for table `addons`
--

CREATE TABLE `addons` (
  `addon_id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `addons`
--

INSERT INTO `addons` (`addon_id`, `name`, `price`) VALUES
(1, 'Extra Bed', 500.00),
(2, 'Extra Pillow', 100.00),
(3, 'Breakfast', 300.00);

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `booking_id` int(11) NOT NULL,
  `guest_id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `check_in` date NOT NULL,
  `check_out` date NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `status` varchar(20) DEFAULT 'Confirmed'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `destinations`
--

CREATE TABLE `destinations` (
  `destination_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `destinations`
--

INSERT INTO `destinations` (`destination_id`, `name`, `type`) VALUES
(1, 'Baguio', 'Local'),
(2, 'Boracay', 'Local'),
(3, 'El Nido', 'Local'),
(4, 'Siargao', 'Local'),
(5, 'Hong Kong', 'International'),
(6, 'Japan', 'International'),
(7, 'Singapore', 'International'),
(8, 'South Korea', 'International');

-- --------------------------------------------------------

--
-- Table structure for table `guests`
--

CREATE TABLE `guests` (
  `guest_id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `age` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL,
  `booking_id` int(11) NOT NULL,
  `payment_method` varchar(20) DEFAULT NULL,
  `amount_paid` decimal(10,2) DEFAULT NULL,
  `transaction_ref` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `room_id` int(11) NOT NULL,
  `room_number` varchar(10) NOT NULL,
  `room_type` varchar(50) NOT NULL,
  `destination_id` int(11) NOT NULL,
  `status` varchar(20) DEFAULT 'Available'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`room_id`, `room_number`, `room_type`, `destination_id`, `status`) VALUES
(1, '101', 'Standard', 1, 'Available'),
(2, '102', 'Deluxe', 1, 'Available'),
(3, '201', 'Suite', 2, 'Available'),
(4, '301', 'Standard', 6, 'Available'),
(5, '401', 'Family', 8, 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `room_rates`
--

CREATE TABLE `room_rates` (
  `rate_id` int(11) NOT NULL,
  `room_type` varchar(50) NOT NULL,
  `destination_type` varchar(20) NOT NULL,
  `season` varchar(20) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `room_rates`
--

INSERT INTO `room_rates` (`rate_id`, `room_type`, `destination_type`, `season`, `price`) VALUES
(1, 'Standard', 'Local', 'Lean', 2000.00),
(2, 'Standard', 'Local', 'High', 4000.00),
(3, 'Standard', 'Local', 'Peak', 6000.00),
(4, 'Standard', 'Local', 'Super Peak', 9000.00),
(5, 'Deluxe', 'Local', 'Lean', 3000.00),
(6, 'Deluxe', 'Local', 'High', 5000.00),
(7, 'Deluxe', 'Local', 'Peak', 8000.00),
(8, 'Deluxe', 'Local', 'Super Peak', 12000.00),
(9, 'Quadruple', 'Local', 'Lean', 4000.00),
(10, 'Quadruple', 'Local', 'High', 7000.00),
(11, 'Quadruple', 'Local', 'Peak', 10000.00),
(12, 'Quadruple', 'Local', 'Super Peak', 15000.00),
(13, 'Family', 'Local', 'Lean', 5000.00),
(14, 'Family', 'Local', 'High', 9000.00),
(15, 'Family', 'Local', 'Peak', 12000.00),
(16, 'Family', 'Local', 'Super Peak', 18000.00),
(17, 'Suite', 'Local', 'Lean', 6000.00),
(18, 'Suite', 'Local', 'High', 11000.00),
(19, 'Suite', 'Local', 'Peak', 14000.00),
(20, 'Suite', 'Local', 'Super Peak', 21000.00),
(21, 'Standard', 'International', 'Lean', 2500.00),
(22, 'Standard', 'International', 'High', 4500.00),
(23, 'Standard', 'International', 'Peak', 6500.00),
(24, 'Standard', 'International', 'Super Peak', 10000.00),
(25, 'Deluxe', 'International', 'Lean', 5000.00),
(26, 'Deluxe', 'International', 'High', 7000.00),
(27, 'Deluxe', 'International', 'Peak', 9000.00),
(28, 'Deluxe', 'International', 'Super Peak', 13000.00),
(29, 'Quadruple', 'International', 'Lean', 7500.00),
(30, 'Quadruple', 'International', 'High', 9500.00),
(31, 'Quadruple', 'International', 'Peak', 11500.00),
(32, 'Quadruple', 'International', 'Super Peak', 16000.00),
(33, 'Family', 'International', 'Lean', 10000.00),
(34, 'Family', 'International', 'High', 12000.00),
(35, 'Family', 'International', 'Peak', 14000.00),
(36, 'Family', 'International', 'Super Peak', 19000.00),
(37, 'Suite', 'International', 'Lean', 12500.00),
(38, 'Suite', 'International', 'High', 14500.00),
(39, 'Suite', 'International', 'Peak', 16500.00),
(40, 'Suite', 'International', 'Super Peak', 22000.00);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addons`
--
ALTER TABLE `addons`
  ADD PRIMARY KEY (`addon_id`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`booking_id`),
  ADD KEY `guest_id` (`guest_id`),
  ADD KEY `room_id` (`room_id`);

--
-- Indexes for table `destinations`
--
ALTER TABLE `destinations`
  ADD PRIMARY KEY (`destination_id`);

--
-- Indexes for table `guests`
--
ALTER TABLE `guests`
  ADD PRIMARY KEY (`guest_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `booking_id` (`booking_id`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`room_id`),
  ADD KEY `destination_id` (`destination_id`);

--
-- Indexes for table `room_rates`
--
ALTER TABLE `room_rates`
  ADD PRIMARY KEY (`rate_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addons`
--
ALTER TABLE `addons`
  MODIFY `addon_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `booking_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `destinations`
--
ALTER TABLE `destinations`
  MODIFY `destination_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `guests`
--
ALTER TABLE `guests`
  MODIFY `guest_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `room_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `room_rates`
--
ALTER TABLE `room_rates`
  MODIFY `rate_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`guest_id`) REFERENCES `guests` (`guest_id`),
  ADD CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`room_id`);

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`booking_id`);

--
-- Constraints for table `rooms`
--
ALTER TABLE `rooms`
  ADD CONSTRAINT `rooms_ibfk_1` FOREIGN KEY (`destination_id`) REFERENCES `destinations` (`destination_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
